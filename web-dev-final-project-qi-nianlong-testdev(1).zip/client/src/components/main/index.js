import "./index.css";
import { useState } from "react";
import SideBarNav from "./sideBarNav";
import QuestionPage from "./questionPage";
import TagPage from "./tagPage";
import AnswerPage from "./answerPage";
import NewQuestion from "./newQuestion";
import NewAnswer from "./newAnswer";
import CommentPage from "./commentPage";
import NewComment from "./newComment";

const Main = ({ search = "", title, setQuesitonPage }) => {
    const [page, setPage] = useState("home");
    const [questionOrder, setQuestionOrder] = useState("newest");
    const [qid, setQid] = useState("");
    const [aid, setAid] = useState("");
    let selected = "";
    let content = null;

    const handleQuestions = () => {
        setQuesitonPage();
        setPage("home");
    };

    const handleTags = () => {
        setPage("tag");
    };

    const handleAnswer = (qid) => {
        setQid(qid);
        setPage("answer");
    };

    const clickTag = (tname) => {
        setQuesitonPage("[" + tname + "]", tname);
        setPage("home");
    };

    const handleNewQuestion = () => {
        setPage("newQuestion");
    };

    const handleNewAnswer = () => {
        setPage("newAnswer");
    };

    const handleMyProfile = () => {
        setQuesitonPage("", "Welcome to your profile", true);
        setPage("myProfile");
    };

    const handleUpdateQuestion = (qid) => {
        setQid(qid);
        setPage("updateQuestion");
        console.log("update question");
    };

    const handleComment = (id, type) => {
        if (type === "answer") {
            setAid(id);
            setPage("commentAnswer");
        }
        else if (type === "question") {
            setQid(id);
            setPage("commentQuestion");
        }
    };

    const handleNewComment = (id, type) => {
        if (type === "answer") {
            setAid(id);
            setPage("newCommentAnswer");
        }
        else if (type === "question") {
            setQid(id);
            setPage("newCommentQuestion");
        }
    }

    const getQuestionPage = (order = "newest", search = "", toMyProfile = false) => {
        return (
            <QuestionPage
                title_text={title}
                order={order}
                search={search}
                setQuestionOrder={setQuestionOrder}
                clickTag={clickTag}
                handleAnswer={handleAnswer}
                handleNewQuestion={handleNewQuestion}
                toMyProfile={toMyProfile}
            />
        );
    };

    switch (page) {
        case "home": {
            selected = "q";
            content = getQuestionPage(questionOrder.toLowerCase(), search,false);
            break;
        }
        case "tag": {
            selected = "t";
            content = (
                <TagPage
                    clickTag={clickTag}
                    handleNewQuestion={handleNewQuestion}
                />
            );
            break;
        }
        case "answer": {
            selected = "";
            content = (
                <AnswerPage
                    qid={qid}
                    handleNewQuestion={handleNewQuestion}
                    handleNewAnswer={handleNewAnswer}
                    handleUpdateQuestion={handleUpdateQuestion}
                    handleComment={handleComment}
                />
            );
            break;
        }
        case "newQuestion": {
            selected = "";
            content = <NewQuestion handleQuestions={handleQuestions} />;
            break;
        }
        case "updateQuestion": {
            selected = "";
            content = <NewQuestion qid={qid} handleQuestions={handleQuestions} />;
            break;
        }
        case "newAnswer": {
            selected = "";
            content = <NewAnswer qid={qid} handleAnswer={handleAnswer} />;
            break;
        }
        case "myProfile": {
            selected = "m";
            content = getQuestionPage(questionOrder.toLowerCase(), search,true);
            break;
        }
        case "commentAnswer": {
            selected = "";
            content = <CommentPage id={aid} type = "answer" handleNewComment={handleNewComment} />;
            break;
        }
        case "commentQuestion": {
            selected = "";
            content = <CommentPage id={qid} type = "question" handleNewComment={handleNewComment} />;
            break;
        }
        case "newCommentAnswer": {
            selected = "";
            content = <NewComment id={aid} type = "answer" handleComment={handleComment} />;
            break;
        }
        case "newCommentQuestion": {
            selected = "";
            content = <NewComment id={qid} type = "question" handleComment={handleComment} />;
            break;
        }
        default:
            selected = "q";
            content = getQuestionPage();
            break;
    }

    return (
        <div id="main" className="main">
            <SideBarNav
                selected={selected}
                handleQuestions={handleQuestions}
                handleTags={handleTags}
                handleMyProfile={handleMyProfile}
            />
            <div id="right_main" className="right_main">
                {content}
            </div>
        </div>
    );
};

export default Main;
